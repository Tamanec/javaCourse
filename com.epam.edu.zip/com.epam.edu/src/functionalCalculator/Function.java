package functionalCalculator;

abstract public class Function {	
	abstract double calculate( double argument );
}
