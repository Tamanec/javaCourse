package functionalCalculator;

public class Cosine extends Function {
	@Override
	double calculate( double argument ) {
		return Math.cos( argument );
	}
}
